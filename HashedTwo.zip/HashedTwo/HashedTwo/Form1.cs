﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HashedTwo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //md5 method --> mixed up with utf8 encoding
        static string Encrypt (string value)
        {
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider()) 
            {
                UTF8Encoding utf8 = new UTF8Encoding ();
                //hash data
                byte [] data = md5.ComputeHash (utf8.GetBytes (value));
                return Convert.ToBase64String (data);
            }
        }
       


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //null point handling 
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Enter a valid string");
                return;
            }
            //else put the hash value into text box 2
            textBox2.Text = Encrypt (textBox1.Text);
        }
    }
}
