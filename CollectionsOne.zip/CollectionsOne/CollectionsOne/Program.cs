﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsOne
{
    class Program
    {
        static void Main(string[] args)
        {
            //recap of non generics --> stack 
            // create an object of the Stack --> using collections 
            // use a stack if you want a "last in first out" --> the item you add to the stack last will be printed first --> example : John was added first but will be printed last
            Stack  st = new Stack();
            // methods --> push/ pop

            //adding items onto the stack 
            st.Push("John");
            st.Push("Sue");
            st.Push("Henry");


            // number of elements in a stack --> count 
            Console.WriteLine("Number of items in the stack >>>>" +  st.Count);

            foreach (var item in st)
            {
                // output is determined by the type of collection --> LIFO
                Console.WriteLine(item);
            }

            Console.WriteLine();

            // Removal of items --> Popping 
            st.Pop();  //limited --> LIFO
            //uses last in first out approach --> by default it will remove the last item from the stack
            foreach (var item in st)
            {
                
                Console.WriteLine(item);
            }



            Console.ReadLine();
        }
    }
}
