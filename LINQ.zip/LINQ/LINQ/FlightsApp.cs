﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ
{
    public partial class FlightsApp : Form
    {
        List<Flight> allFlights = new List<Flight>();
        List<Flight> filtered;
        public FlightsApp()
        {
            InitializeComponent();
        }

        private void FlightsApp_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;

            comboBox2.Visible = false;
            comboBox3.Visible = false;
            try
            {
                StreamReader file = new StreamReader("Flights.txt");
                string line;

                while ((line = file.ReadLine()) != null)
                {
                    string[] lineParts = line.Split(',');
                    string flightNo = lineParts[0];
                    DateTime time = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, Convert.ToInt32(lineParts[1].Split()));
                    string destination = lineParts[2];
                    string gate = lineParts[3];
                    double price = Convert.ToDouble(lineParts[4]);

                    Flight temp = new Flight(flightNo, time, destination, gate, price);
                    allFlights.Add(temp);
                }
                file.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            listBox1.Items.Clear();
            foreach(Flight f in allFlights)
            {
                //listBox1.Items.Add(f);
                
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            if (comboBox1.SelectedItem != null)
            {
                string option = comboBox1.SelectedItem.ToString();
                switch (option)
                {
                    case "Flights to Cape Town, ordered in alphabetical order of airlines":
                        //method syntax
                        filtered = allFlights.Where(f => f.Destination.Equals("Cape Town")).OrderBy(fn => fn.FlightNo).ToList();

                        filtered = (from f in allFlights
                                    where(f.Destination == "Cape Town")
                                    orderby f.FlightNo
                                    select f).ToList();
                        break;
                    case "Flight departing from Gate A11, ordered by departure time":

                        break;
                    case "Flights to Johannesburg which cost less than R600, ordered by price (ascending)":

                        break;
                    case "Choose own airline and destination":
                        if (comboBox2.SelectedItem != null && comboBox3.SelectedItem != null)
                        {
                           filtered = allFlights.Where(f => f.Airline().Equals(comboBox2.SelectedItem)
                           && f.Destination.Equals(comboBox3.SelectedItem)).ToList();
                        }

                        break;

                }
            }
        }
    }
}
