﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GridViewWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // to use the courses class
            Courses courses = new Courses();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //validation --> optional 
            if (tbCourseName.Text.Length == 0 ||
                tbCourseCode.Text.Length == 0 || tbCredits.Text.Length ==0 )
            {
                MessageBox.Show("Fields cannot be left blank >>>>");
            }
            else
            {
                // confirm if entry is correct before sending to the DGV
                if(MessageBox.Show("Is the entry correct? ",
                    "Confirm Entry", MessageBoxButton.YesNo)
                    == MessageBoxResult.Yes)
                {
                    //pull info from the boxes 
                    Courses temp = new Courses();
                    temp.courseName = tbCourseName.Text;
                    temp.courseCode = tbCourseCode.Text;
                    temp.noCredits = tbCredits.Text;
                    temp.classHrs = Convert.ToInt32(tbClassHrs.Text);

                    DGCourses.Items.Add(temp);
                } 
                    {

                }
            }
        }

        private void DGCourses_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
