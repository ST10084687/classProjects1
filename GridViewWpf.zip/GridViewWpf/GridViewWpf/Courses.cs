﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GridViewWpf
{
    class Courses
    {
        //props
        public string courseName { get; set; }
        public string courseCode { get; set; }
        public string noCredits { get; set; }
        public int classHrs { get; set; }
        public int numWeeks { get; set; }
        public int totalHours { get; set; }

    }
}
