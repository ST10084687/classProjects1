﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserRegistration
{
    class User
    {
        public string name;
        public string surname;
        public string password;
        public string email;
        public string username;

        public object this[int index]
        {
            get
            {
                if (index == 0)
                    return name;
                else if (index == 1)
                    return surname;
                else if (index == 2)
                    return email;
                else if (index == 3)
                    return username;
                else if (index == 4)
                    return password;
                else return null;
            }
        }
    }
}
