﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoWpfDesigns
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void MouseClick(Object sender , MouseButtonEventArgs e)
        {
            //to handle mouse click events 
        }

        private void ListViewItem4_Selected(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ListViewItem2_Selected(object sender, RoutedEventArgs e)
        {
            // to move to another window 
            // create an object of the other screen 
            Control c = new Control();
            this.Close();//close the current screen
            c.Show();//visible
        }
    }
}
