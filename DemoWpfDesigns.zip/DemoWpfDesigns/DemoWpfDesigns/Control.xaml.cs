﻿using System.Windows;

namespace DemoWpfDesigns
{
    /// <summary>
    /// Interaction logic for Control.xaml
    /// </summary>
    public partial class Control : Window
    {
        public Control()
        {
            InitializeComponent();
        }

        private void nxtBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void backBtn_Click_1(object sender, RoutedEventArgs e)
        {
           
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {

            MainWindow mw = new MainWindow();
            this.Close();
            mw.Show();
        }
    }
}
