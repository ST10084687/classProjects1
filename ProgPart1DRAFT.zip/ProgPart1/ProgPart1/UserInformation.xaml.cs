﻿using ProgPoeDll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static ProgPoeDll.Class1;

namespace ProgPart1
{
    /// <summary>
    /// Interaction logic for UserInformation.xaml
    /// </summary>
    public partial class UserInformation : Window
    {
        courseInformation information = new courseInformation();
        //courseInformation information = new courseInformation();
        List<courseInformation> informationList = new List<courseInformation>();

        Class1 cl = new Class1();
        public UserInformation()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SemesterInformation semesterInformation = new SemesterInformation();
            semesterInformation.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            
            

            if (MessageBox.Show("Is the entry correct? ",
               "Confirm Entry", MessageBoxButton.YesNo)
               == MessageBoxResult.Yes)
            {

            
             
                information.courseName = tbCourseName.Text;
                information.courseCode = tbCourseCode.Text;
                information.credits = Convert.ToInt32(tbCredits.Text);
                information.classHours = Convert.ToInt32(tbHours.Text);
                information.semesterWeeks = Convert.ToInt32(tbWeeks.Text);
                information.selfStudyHoursPerWeek = cl.selfStudyHoursCalculation(Convert.ToInt32(tbCredits.Text), Convert.ToInt32(tbWeeks.Text) ,Convert.ToInt32(tbHours.Text));
                information.hoursRemaining = cl.hoursCalc(information.selfStudyHoursPerWeek, Convert.ToInt32(tbHours.Text));

                DataGrid1.Items.Add(information);

               
               
            }


        }

       
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
          tbCourseName.Clear();
            tbCourseCode.Clear();
            tbCredits.Clear();
            tbHours.Clear();
            tbWeeks.Clear();
        }

       

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            var sorted =
                from information in informationList
                orderby information.courseName
                select information.courseName;

            foreach (var element in sorted)
            {
                DataGrid1.Items.Add(element);
            }

        }
    }
    }

