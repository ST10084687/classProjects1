﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace budgetApp
{

    class Rent : Expenses

    {
        
        private double rentalAmount;

        public Rent()
        {
            //this.rentalAmount = rentalAmount;

        }

        

        double monthlyRentalAmount()
        {
            Console.WriteLine("Please enter the Monthly Rental Amount: ");
            rentalAmount = Convert.ToDouble(Console.ReadLine());
            return rentalAmount;
        }
    }
}
