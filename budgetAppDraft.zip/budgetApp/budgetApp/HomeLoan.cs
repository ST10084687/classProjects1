﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace budgetApp
{
     class HomeLoan : Rent
    {
        private double price;
        private double deposit;
        private double interestRate;
        private double monthsToPay;
        private double homeLoanRepayments;


        

         public double monthlyRentalAmount()
        {
            double totalAmount;
            double years;
            double amountOwed;

            Console.Write("Please enter the Purchase Price of the Property: ");
            price = Convert.ToDouble(Console.ReadLine());

            Console.Write("Please enter the Total Deposit: ");
            deposit = Convert.ToDouble(Console.ReadLine());

            Console.Write("Please enter the Interest Rate: ");
            interestRate = Convert.ToDouble(Console.ReadLine());

            Console.Write("Please enter the Number of Months to Repay(240 or 360): ");
            monthsToPay = Convert.ToDouble(Console.ReadLine());

            totalAmount = price - deposit;
            interestRate = interestRate / 100;
            years = monthsToPay / 12;

            amountOwed = totalAmount * (1 + (interestRate * years));

            homeLoanRepayments = amountOwed / monthsToPay;
            homeLoanRepayments = Math.Round(homeLoanRepayments, 2);

            return homeLoanRepayments;
        }


    }
}
