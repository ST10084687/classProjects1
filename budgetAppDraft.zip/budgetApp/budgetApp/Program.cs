﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace budgetApp
{
    class Program
    {
        private static double grossMonthlyIncome;
        private static double monthlyTaxDeducted;
        private static List<double> expenses = new List<double>();
        private static double finalExpenses;
        private static double rentCosts;
        



        public static void Main(string[] args)
        {
            splashScreen();
            //Console.WriteLine();

            //Console.WriteLine("==================================");

            Input();
            Console.WriteLine("==================================");

            userEntersExpenses();
            Console.WriteLine("==================================");

            rentingOrBuying();
            Console.WriteLine("==================================");




            void splashScreen()
            {
            
            //Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("Loading . . . . ");


            //count backwards
            for (int i = 3; i > 0; i--)
            {
                Console.Write(i + " ");
                Thread.Sleep(500);
            }

            Console.WriteLine("\n \n==================================");
            Console.WriteLine("Welcome to Budget Planner App");
            Console.WriteLine("==================================");
            Thread.Sleep(500); //MAX 5000
        }

        }
        static void Input()
        {
            Console.ForegroundColor = ConsoleColor.White;


            Console.Write("Please enter your Gross Monthly Income(before deductions): ");
            grossMonthlyIncome = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();

            Console.Write("Please enter your Estimated Monthly Tax Deducted: ");
            monthlyTaxDeducted = Convert.ToDouble(Console.ReadLine());


            Console.ReadLine();
        }

        static void userEntersExpenses()
        {
            Console.Write("\nPlease enter your Monthly Expenditure on Groceries: ");
            expenses.Add(Convert.ToDouble(Console.ReadLine()));


            Console.Write("\nPlease enter your Monthly Expenditure on Water and Lights: ");
            expenses.Add(Convert.ToDouble(Console.ReadLine()));

            Console.Write("\nPlease enter your Monthly Expenditure on Travel Costs: ");
            expenses.Add(Convert.ToDouble(Console.ReadLine()));

            Console.Write("\nPlease enter your Monthly Expenditure on Cell Phone and Telephone: ");
            expenses.Add(Convert.ToDouble(Console.ReadLine()));

            Console.Write("\nPlease enter your Monthly Expenditure on Other Expenses: ");
            expenses.Add(Convert.ToDouble(Console.ReadLine()));
        }

        static void rentingAccomodation()
        {
            Rent theExpenses = new Rent();
            theExpenses.setExpenses(expenses);

            finalExpenses = theExpenses.getTotalExpense();

            rentCosts = theExpenses.monthlyRentalAmount();



        }
        static void buyingProperty()
        {
            HomeLoan theExpenses = new HomeLoan();
            theExpenses.setExpenses(expenses);

            finalExpenses = theExpenses.getTotalExpense();

            rentCosts = theExpenses.monthlyRentalAmount();
        }


        static void rentingOrBuying()
        {
            Console.Write("Enter 1 if you will be RENTING accomodation or Enter 2 if you will be BUYING a property: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            if (choice == 1)
            {
                
                rentingAccomodation();
            }
            else if (choice == 2)
            {
                buyingProperty();

            }
        }
            
        
            
        }
    }

