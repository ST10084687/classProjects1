﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace budgetApp
{
    abstract class Expenses
    {


        private double finalExpenses = 0;
        private List<double> expenses = new List<double>();

        public void setExpenses(List<double> usersExpenses)
        {
            expenses = usersExpenses;
        }
        public double getTotalExpense()
        {
            finalExpenses = expenses.Sum();
            return finalExpenses;
        }
    }
}
