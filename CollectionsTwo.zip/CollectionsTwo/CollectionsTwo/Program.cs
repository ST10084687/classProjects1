﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            //non generic --> queue
            // create an object of the queue
            //does total opposite of the STACK
            //FIFO --> First in first out 

            Queue qOne = new Queue();
            //storage --> FIFO 
            //storage --> first in first out
            //the way you type it in is the way it appears


            //Methods --> enqueue && dequeue
            qOne.Enqueue(1);
            qOne.Enqueue(2);
            qOne.Enqueue(3);

            Console.WriteLine("Items in the queue >>>> \n");
            
            foreach (var item in qOne)
            {
                Console.WriteLine(item);
            }


            //remove an item 
            qOne.Dequeue();//apply FIFO
            // removes first item in the list
            Console.WriteLine("\n\n");
            foreach (var item in qOne)
            {
                Console.WriteLine(item);
            }



            Console.ReadLine();
        }
    }
}
