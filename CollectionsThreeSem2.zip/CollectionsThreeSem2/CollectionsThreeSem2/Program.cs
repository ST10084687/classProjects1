﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsThreeSem2
{
    class Program
    {
        static void Main(string[] args)
        {
            // non generic -- hashtable 
            // create an object 
            Hashtable hash = new Hashtable();



            //stores in key value pairs 
            // key value

            // adding some items 
            hash.Add(1, "One");
            hash.Add(2, "Two");
            hash.Add(3, "Three");


            //hashtables --> retrieved using a dictionary entry item
            // output
            foreach(DictionaryEntry item in hash)
            {
                Console.WriteLine("Key: {0}, value: {1}", item.Key, item.Value);
            }


            Console.ReadLine();

        }
    }
}
