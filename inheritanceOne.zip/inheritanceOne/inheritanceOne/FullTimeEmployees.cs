﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritanceOne
{
    public class FullTimeEmployees : Employees
    {

        // its own prop
        public string lunch;

        //public override void;

        // override the virtual method in the base class

        public override void printInfo()
        {
            Console.WriteLine("Printitng from the derived class");
            base.printInfo();
        }
    }
}
