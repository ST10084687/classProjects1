﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritanceOne
{
    public class PartTimeEmployees : Employees
    {
        public int hours;
    }
}
